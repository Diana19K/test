let btn = document.getElementById("knop");
btn.addEventListener("click", a_menuV);
function a_menuV(){
let modal = document.getElementsByClassName("model")[0];
modal.style.top = "50%";
}
let but = document.getElementById("closeModal"); 
 
but.addEventListener("click", closeModal); 
 
function closeModal(){ 
    let model = document.getElementsByClassName("model")[0]; 
    console.log(model); 
    model.style.top = "-50%"; 
}